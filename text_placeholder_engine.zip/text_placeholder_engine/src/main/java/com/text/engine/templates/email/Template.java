package com.text.engine.templates.email;

public interface Template {
  String getSubject();

  String getResourcePath();
}
